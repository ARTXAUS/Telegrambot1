package danylo.bot.handler;

import danylo.bot.BotCondition;
import danylo.bot.handler.message.MessageHandler;
import org.springframework.stereotype.Component;

import org.telegram.telegrambots.meta.api.methods.BotApiMethod;
import org.telegram.telegrambots.meta.api.objects.Message;

import java.util.List;

@Component
public class BotConditionHandler {

    private final List<MessageHandler> messageHandlers;

    public BotConditionHandler(List<MessageHandler> messageHandlers) {
        this.messageHandlers = messageHandlers;
    }

    public BotApiMethod<Message> handleTextMessageByCondition(Message message, BotCondition botCondition) {
        return messageHandlers.stream()
                .filter(h -> h.canHandle(botCondition))
                .findAny()
                .orElseThrow(IllegalArgumentException::new)
                .handle(message);
    }

}

